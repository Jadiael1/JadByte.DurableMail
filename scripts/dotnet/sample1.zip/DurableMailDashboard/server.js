const express = require('express');
const mariadb = require('mariadb');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

// Create a connection pool for MariaDB
const pool = mariadb.createPool({
    host: 'localhost',
    port: 3306,
    user: 'root',
    password: '',
    database: '',
    connectionLimit: 10
});

app.get('/api/stats', async (req, res) => {
    let conn;
    try {
        conn = await pool.getConnection();
        const statusCounts = await conn.query(`
            SELECT status, COUNT(*) as count
            FROM durable_mail_deliveries
            GROUP BY status
        `);

        // Status enum: 0=Pending, 1=Processing, 2=Succeeded, 3=Failed, 4=Superseded
        const stats = {
            total: 0,
            pending: 0,
            processing: 0,
            succeeded: 0,
            failed: 0,
            superseded: 0
        };

        statusCounts.forEach(row => {
            stats.total += Number(row.count);
            if (row.status === 0) stats.pending = Number(row.count);
            if (row.status === 1) stats.processing = Number(row.count);
            if (row.status === 2) stats.succeeded = Number(row.count);
            if (row.status === 3) stats.failed = Number(row.count);
            if (row.status === 4) stats.superseded = Number(row.count);
        });

        // Also get average attempts for succeeded
        const avgAttemptsRow = await conn.query(`
            SELECT AVG(attempt_count) as avg_attempts
            FROM durable_mail_deliveries
            WHERE status = 2
        `);
        stats.avg_attempts = avgAttemptsRow[0]?.avg_attempts || 0;

        res.json(stats);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal Server Error' });
    } finally {
        if (conn) conn.release();
    }
});

app.get('/api/recent-failures', async (req, res) => {
    let conn;
    try {
        conn = await pool.getConnection();
        const failures = await conn.query(`
            SELECT a.id, a.started_at, a.error_type, a.error_message, a.stack_trace, d.recipient, d.subject
            FROM durable_mail_attempts a
            JOIN durable_mail_deliveries d ON a.email_delivery_id = d.id
            WHERE a.outcome IN (1, 2) -- TransientFailure or PermanentFailure
            ORDER BY a.started_at DESC
            LIMIT 10
        `);
        // Convert BigInt to string if present (mariadb returns BigInt for BIGINT columns by default, JSON stringify fails)
        const serializedFailures = failures.map(f => {
            return {
                ...f,
                started_at: typeof f.started_at === 'bigint' ? f.started_at.toString() : f.started_at
            };
        });
        res.json(serializedFailures);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal Server Error' });
    } finally {
        if (conn) conn.release();
    }
});

app.get('/api/deliveries', async (req, res) => {
    let conn;
    try {
        conn = await pool.getConnection();
        const deliveries = await conn.query(`
            SELECT id, recipient, subject, status, created_at, updated_at, attempt_count
            FROM durable_mail_deliveries
            ORDER BY created_at DESC
            LIMIT 20
        `);

        // Convert BigInt to string if present
        const serializedDeliveries = deliveries.map(d => {
            return {
                ...d,
                created_at: typeof d.created_at === 'bigint' ? d.created_at.toString() : d.created_at,
                updated_at: typeof d.updated_at === 'bigint' ? d.updated_at.toString() : d.updated_at,
            };
        });
        res.json(serializedDeliveries);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal Server Error' });
    } finally {
        if (conn) conn.release();
    }
});

const PORT = process.env.PORT || 3005;
app.listen(PORT, () => {
    console.log(`DurableMail MariaDB Dashboard API running on http://localhost:${PORT}`);
});
