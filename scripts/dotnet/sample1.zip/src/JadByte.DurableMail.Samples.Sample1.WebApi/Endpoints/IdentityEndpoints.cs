using JadByte.DurableMail.Samples.Sample1.Infrastructure.Identity;
using Microsoft.AspNetCore.Routing.Patterns;

namespace JadByte.DurableMail.Samples.Sample1.WebApi.Endpoints;

public static class IdentityEndpoints
{
    public static IEndpointRouteBuilder MapIdentityEndpoints(this IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/v1").WithTags("Identity");

        group.MapIdentityApi<ApplicationUser>()
            .Add(endpointBuilder =>
            {
                if (endpointBuilder is not RouteEndpointBuilder route)
                    return;

                route.RoutePattern = route.RoutePattern.RawText switch
                {
                    "/v1/register" => RoutePatternFactory.Parse("/v1/signUp"),
                    "/v1/login" => RoutePatternFactory.Parse("/v1/signIn"),
                    _ => route.RoutePattern
                };
            });

        return endpoints;
    }
}
