using JadByte.DurableMail.Samples.Sample1.WebApi.Endpoints;

namespace JadByte.DurableMail.Samples.Sample1.WebApi.Extensions;

public static class EndpointExtensions
{
    public static WebApplication MapEndpoints(this WebApplication app)
    {
        app.MapIdentityEndpoints();

        return app;
    }
}
