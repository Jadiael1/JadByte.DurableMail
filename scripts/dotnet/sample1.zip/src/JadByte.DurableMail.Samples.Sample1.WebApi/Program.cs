using JadByte.DurableMail.Samples.Sample1.Infrastructure.Identity;
using JadByte.DurableMail.Samples.Sample1.Infrastructure.Persistence.Contexts;
using OpenTelemetry.Metrics;
using Scalar.AspNetCore;
using JadByte.DurableMail.Samples.Sample1.WebApi.Extensions;
using JadByte.DurableMail.Samples.Sample1.Infrastructure;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddIdentityApiEndpoints<ApplicationUser>(options =>
{
    options.SignIn.RequireConfirmedEmail = true;
    options.User.RequireUniqueEmail = true;
})
.AddEntityFrameworkStores<ApplicationDbContext>();

builder.Services.AddInfrastructure(builder.Configuration);

// Add services to the container.
// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();

builder.Services.AddOpenTelemetry()
    .WithMetrics(metrics =>
    {
        metrics.AddAspNetCoreInstrumentation()
               .AddRuntimeInstrumentation()
               .AddPrometheusExporter();
    });

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    try
    {
        var context = services.GetRequiredService<ApplicationDbContext>();
        await context.Database.MigrateAsync();
    }
    catch (Exception ex)
    {
        var logger = services.GetRequiredService<ILogger<Program>>();
        logger.LogError(ex, "An error occurred while applying migrations to the database.");
        throw;
    }
}

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.MapScalarApiReference("/", options => options
            .WithTheme(ScalarTheme.BluePlanet)
            .EnablePersistentAuthentication());
}

app.UseHttpsRedirection();

app.MapEndpoints();

app.MapPrometheusScrapingEndpoint();

await app.RunAsync();
