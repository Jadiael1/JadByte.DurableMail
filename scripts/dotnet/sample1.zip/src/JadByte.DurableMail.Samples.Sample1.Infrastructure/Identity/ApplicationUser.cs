using Microsoft.AspNetCore.Identity;

namespace JadByte.DurableMail.Samples.Sample1.Infrastructure.Identity;

public class ApplicationUser : IdentityUser
{

}
