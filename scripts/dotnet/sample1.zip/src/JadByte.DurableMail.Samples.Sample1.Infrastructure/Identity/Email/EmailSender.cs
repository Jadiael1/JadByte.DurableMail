using Microsoft.AspNetCore.Identity;

namespace JadByte.DurableMail.Samples.Sample1.Infrastructure.Identity.Email;

public sealed class EmailSender(IEmailQueue emailQueue) : IEmailSender<ApplicationUser>
{
    public Task SendConfirmationLinkAsync(ApplicationUser user, string email, string confirmationLink) =>
        EnqueueEmailAsync(email, "Confirme seu e-mail", $"Por favor, confirme sua conta clicando <a href='{confirmationLink}'>aqui</a>.", "identity:confirmation");

    public Task SendPasswordResetLinkAsync(ApplicationUser user, string email, string resetLink) =>
        EnqueueEmailAsync(email, "Redefinição de senha", $"Redefina sua senha clicando <a href='{resetLink}'>aqui</a>.", "identity:password-reset");

    public Task SendPasswordResetCodeAsync(ApplicationUser user, string email, string resetCode) =>
        EnqueueEmailAsync(email, "Código de redefinição", $"Seu código de redefinição é: {resetCode}", "identity:password-reset-code");

    private async Task EnqueueEmailAsync(string toEmail, string subject, string htmlMessage, string source)
    {
        var message = new EmailMessage(toEmail, subject, htmlMessage, EmailBodyFormat.Html);
        var request = new EmailEnqueueRequest(message, Source: source);
        await emailQueue.EnqueueAsync(request);
    }
}
