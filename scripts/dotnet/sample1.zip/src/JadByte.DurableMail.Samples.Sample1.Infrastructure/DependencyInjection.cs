using JadByte.DurableMail.Samples.Sample1.Infrastructure.Identity;
using JadByte.DurableMail.Samples.Sample1.Infrastructure.Identity.Email;
using JadByte.DurableMail.Samples.Sample1.Infrastructure.Persistence.Contexts;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using JadByte.DurableMail.EntityFrameworkCore;
using JadByte.DurableMail.MailKit;

namespace JadByte.DurableMail.Samples.Sample1.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("DefaultConnection");
        services.AddDbContext<ApplicationDbContext>(
            options => options.UseMySql(
                    connectionString,
                    ServerVersion.AutoDetect(connectionString),
                    mySqlOptions => mySqlOptions.MigrationsHistoryTable("__ef_migrations_history")
                )
                .UseSnakeCaseNamingConvention()
            );

        services.AddOptions<SmtpOptions>()
            .Bind(configuration.GetSection(SmtpOptions.SectionName))
            .Validate(
                options => !string.IsNullOrWhiteSpace(options.Host),
                "Smtp:Host is required.")
            .Validate(
                options => options.Port is > 0 and <= 65535,
                "Smtp:Port is invalid.")
            .Validate(
                options => !string.IsNullOrWhiteSpace(options.FromName),
                "Smtp:FromName is required.")
            .Validate(
                options => !string.IsNullOrWhiteSpace(options.FromEmail),
                "Smtp:FromEmail is required.")
            .Validate(
                options =>
                    string.IsNullOrWhiteSpace(options.Username) ==
                    string.IsNullOrWhiteSpace(options.Password),
                "Smtp:Username and Smtp:Password must both be configured or both omitted.")
            .ValidateOnStart();

        services.AddTransient<IEmailSender<ApplicationUser>, EmailSender>();

        services.AddDurableMail(options =>
        {
            options.Retries.Scheduled.Enabled = true;
        })
        .UseEntityFrameworkCore<ApplicationDbContext>()
        .UseMailKit(configuration.GetSection(SmtpOptions.SectionName));

        return services;
    }
}
